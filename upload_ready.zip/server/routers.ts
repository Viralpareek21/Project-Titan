import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getUserGoals,
  createGoal,
  updateGoal,
  deleteGoal,
  getChatHistory,
  addChatMessage,
  getUserCalendarEvents,
  createCalendarEvent,
  updateCalendarEvent,
  deleteCalendarEvent,
  getUserNotes,
  createNote,
  updateNote,
  deleteNote,
  getUserFlashcards,
  createFlashcard,
  updateFlashcard,
  deleteFlashcard,
  getUserKanbanBoards,
  createKanbanBoard,
  getBoardCards,
  createKanbanCard,
  updateKanbanCard,
  deleteKanbanCard,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Goals procedures
  goals: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserGoals(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().optional(),
          category: z.enum(["personal", "health", "career", "education", "finance"]),
          deadline: z.date().optional(),
        })
      )
      .mutation(({ ctx, input }) =>
        createGoal({
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          category: input.category,
          deadline: input.deadline,
          progress: 0,
          status: "active",
        })
      ),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          description: z.string().optional(),
          progress: z.number().min(0).max(100).optional(),
          status: z.enum(["active", "completed", "paused", "archived"]).optional(),
        })
      )
      .mutation(({ input }) => updateGoal(input.id, input)),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteGoal(input.id)),
  }),

  // Chat procedures
  chat: router({
    history: protectedProcedure
      .input(z.object({ limit: z.number().default(50) }).optional())
      .query(({ ctx, input }) =>
        getChatHistory(ctx.user.id, input?.limit)
      ),
    send: protectedProcedure
      .input(
        z.object({
          content: z.string().min(1),
        })
      )
      .mutation(async ({ ctx, input }) => {
        // Add user message
        await addChatMessage({
          userId: ctx.user.id,
          content: input.content,
          role: "user",
        });

        // TODO: Call LLM API here to generate response
        // For now, return a placeholder response
        const assistantMessage = await addChatMessage({
          userId: ctx.user.id,
          content: "I received your message. LLM integration coming soon.",
          role: "assistant",
        });

        return assistantMessage;
      }),
  }),

  // Calendar procedures
  calendar: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserCalendarEvents(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          description: z.string().optional(),
          startTime: z.date(),
          endTime: z.date(),
          color: z.string().default("blue"),
        })
      )
      .mutation(({ ctx, input }) =>
        createCalendarEvent({
          userId: ctx.user.id,
          ...input,
        })
      ),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          description: z.string().optional(),
          startTime: z.date().optional(),
          endTime: z.date().optional(),
          color: z.string().optional(),
        })
      )
      .mutation(({ input }) => updateCalendarEvent(input.id, input)),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteCalendarEvent(input.id)),
  }),

  // Notes procedures
  notes: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserNotes(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          title: z.string().min(1),
          content: z.string(),
          mode: z.enum(["study", "business"]),
        })
      )
      .mutation(({ ctx, input }) =>
        createNote({
          userId: ctx.user.id,
          ...input,
        })
      ),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          content: z.string().optional(),
          mode: z.enum(["study", "business"]).optional(),
        })
      )
      .mutation(({ input }) => updateNote(input.id, input)),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteNote(input.id)),
  }),

  // Flashcards procedures
  flashcards: router({
    list: protectedProcedure.query(({ ctx }) =>
      getUserFlashcards(ctx.user.id)
    ),
    create: protectedProcedure
      .input(
        z.object({
          question: z.string().min(1),
          answer: z.string().min(1),
          category: z.string().min(1),
          difficulty: z.enum(["easy", "medium", "hard"]).default("medium"),
        })
      )
      .mutation(({ ctx, input }) =>
        createFlashcard({
          userId: ctx.user.id,
          ...input,
        })
      ),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          question: z.string().optional(),
          answer: z.string().optional(),
          difficulty: z.enum(["easy", "medium", "hard"]).optional(),
          reviewCount: z.number().optional(),
        })
      )
      .mutation(({ input }) => updateFlashcard(input.id, input)),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteFlashcard(input.id)),
  }),

  // Kanban procedures
  kanban: router({
    boards: protectedProcedure.query(({ ctx }) =>
      getUserKanbanBoards(ctx.user.id)
    ),
    createBoard: protectedProcedure
      .input(z.object({ title: z.string().min(1) }))
      .mutation(({ ctx, input }) =>
        createKanbanBoard({
          userId: ctx.user.id,
          title: input.title,
        })
      ),
    cards: protectedProcedure
      .input(z.object({ boardId: z.number() }))
      .query(({ input }) => getBoardCards(input.boardId)),
    createCard: protectedProcedure
      .input(
        z.object({
          boardId: z.number(),
          title: z.string().min(1),
          description: z.string().optional(),
          status: z.enum(["todo", "in_progress", "review", "done"]).default("todo"),
        })
      )
      .mutation(({ input }) =>
        createKanbanCard({
          boardId: input.boardId,
          title: input.title,
          description: input.description,
          status: input.status,
          order: 0,
        })
      ),
    updateCard: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          title: z.string().optional(),
          description: z.string().optional(),
          status: z.enum(["todo", "in_progress", "review", "done"]).optional(),
          order: z.number().optional(),
        })
      )
      .mutation(({ input }) => updateKanbanCard(input.id, input)),
    deleteCard: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(({ input }) => deleteKanbanCard(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
