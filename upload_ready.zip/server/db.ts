import { asc, desc, eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, goals, InsertGoal, chatMessages, InsertChatMessage, calendarEvents, InsertCalendarEvent, notes, InsertNote, flashcards, InsertFlashcard, kanbanBoards, InsertKanbanBoard, kanbanCards, InsertKanbanCard } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Goals queries
export async function getUserGoals(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(goals).where(eq(goals.userId, userId)).orderBy(desc(goals.createdAt));
}

export async function createGoal(goal: InsertGoal) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(goals).values(goal);
  return result;
}

export async function updateGoal(id: number, updates: Partial<InsertGoal>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(goals).set(updates).where(eq(goals.id, id));
}

export async function deleteGoal(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(goals).where(eq(goals.id, id));
}

// Chat messages queries
export async function getChatHistory(userId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(chatMessages).where(eq(chatMessages.userId, userId)).orderBy(desc(chatMessages.createdAt)).limit(limit);
}

export async function addChatMessage(message: InsertChatMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(chatMessages).values(message);
}

// Calendar events queries
export async function getUserCalendarEvents(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(calendarEvents).where(eq(calendarEvents.userId, userId)).orderBy(asc(calendarEvents.startTime));
}

export async function createCalendarEvent(event: InsertCalendarEvent) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(calendarEvents).values(event);
}

export async function updateCalendarEvent(id: number, updates: Partial<InsertCalendarEvent>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(calendarEvents).set(updates).where(eq(calendarEvents.id, id));
}

export async function deleteCalendarEvent(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(calendarEvents).where(eq(calendarEvents.id, id));
}

// Notes queries
export async function getUserNotes(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(notes).where(eq(notes.userId, userId)).orderBy(desc(notes.updatedAt));
}

export async function createNote(note: InsertNote) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(notes).values(note);
}

export async function updateNote(id: number, updates: Partial<InsertNote>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(notes).set(updates).where(eq(notes.id, id));
}

export async function deleteNote(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(notes).where(eq(notes.id, id));
}

// Flashcards queries
export async function getUserFlashcards(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(flashcards).where(eq(flashcards.userId, userId)).orderBy(desc(flashcards.createdAt));
}

export async function createFlashcard(card: InsertFlashcard) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(flashcards).values(card);
}

export async function updateFlashcard(id: number, updates: Partial<InsertFlashcard>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(flashcards).set(updates).where(eq(flashcards.id, id));
}

export async function deleteFlashcard(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(flashcards).where(eq(flashcards.id, id));
}

// Kanban queries
export async function getUserKanbanBoards(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(kanbanBoards).where(eq(kanbanBoards.userId, userId)).orderBy(desc(kanbanBoards.createdAt));
}

export async function createKanbanBoard(board: InsertKanbanBoard) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(kanbanBoards).values(board);
}

export async function getBoardCards(boardId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(kanbanCards).where(eq(kanbanCards.boardId, boardId)).orderBy(asc(kanbanCards.order));
}

export async function createKanbanCard(card: InsertKanbanCard) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.insert(kanbanCards).values(card);
}

export async function updateKanbanCard(id: number, updates: Partial<InsertKanbanCard>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.update(kanbanCards).set(updates).where(eq(kanbanCards.id, id));
}

export async function deleteKanbanCard(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  return db.delete(kanbanCards).where(eq(kanbanCards.id, id));
}
