import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Menu, LogOut, User } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { getLoginUrl } from "@/const";
import { UserProfileModal } from "./UserProfileModal";

interface NavbarProps {
  onMenuToggle?: () => void;
}

export function Navbar({ onMenuToggle }: NavbarProps) {
  const { user, logout, isAuthenticated } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);

  const handleLogout = async () => {
    setIsLoggingOut(true);
    await logout();
  };

  return (
    <>
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="sticky top-0 z-50 w-full border-b border-border/50 bg-background/80 backdrop-blur-xl"
      >
        <div className="flex items-center justify-between px-4 py-3 sm:px-6">
          {/* Logo */}
          <motion.div
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="flex items-center gap-2"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-accent to-accent/50 neon-glow">
              <svg
                viewBox="0 0 24 24"
                className="h-5 w-5 text-accent-foreground"
                fill="currentColor"
              >
                <circle cx="12" cy="12" r="10" opacity="0.3" />
                <circle cx="12" cy="12" r="6" opacity="0.6" />
                <circle cx="12" cy="12" r="2" />
              </svg>
            </div>
            <span className="hidden text-lg font-bold text-foreground sm:inline">
              Titan.Ai
            </span>
          </motion.div>

          {/* Right section */}
          <div className="flex items-center gap-3">
            {/* Menu toggle for mobile */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onMenuToggle}
              className="rounded-lg p-2 hover:bg-muted lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </motion.button>

            {/* Auth section */}
            {isAuthenticated && user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="flex items-center gap-2 rounded-lg px-3 py-2 hover:bg-muted transition-all duration-300"
                  >
                    <div className="h-8 w-8 rounded-full bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center neon-glow-sm">
                      <User className="h-4 w-4 text-accent-foreground" />
                    </div>
                    <span className="hidden text-sm font-medium text-foreground sm:inline">
                      {user.name || "User"}
                    </span>
                  </motion.button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                  <DropdownMenuItem onClick={() => setIsProfileOpen(true)}>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} disabled={isLoggingOut}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>{isLoggingOut ? "Logging out..." : "Logout"}</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  asChild
                  variant="default"
                  size="sm"
                  className="neon-glow"
                >
                  <a href={getLoginUrl()}>Login</a>
                </Button>
              </motion.div>
            )}
          </div>
        </div>
      </motion.nav>

      <UserProfileModal
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        user={user}
        onLogout={handleLogout}
      />
    </>
  );
}
