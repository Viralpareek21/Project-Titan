import { motion } from "framer-motion";
import { User, Mail, LogOut, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface UserProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  user: {
    name?: string | null;
    email?: string | null;
  } | null;
  onLogout: () => void;
}

export function UserProfileModal({
  isOpen,
  onClose,
  user,
  onLogout,
}: UserProfileModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>User Profile</DialogTitle>
        </DialogHeader>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="space-y-6"
        >
          {/* Profile Avatar */}
          <div className="flex justify-center">
            <div className="h-20 w-20 rounded-full bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center neon-glow">
              <User className="h-10 w-10 text-accent-foreground" />
            </div>
          </div>

          {/* User Info */}
          <div className="space-y-4">
            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-sm text-muted-foreground mb-1">Name</p>
              <p className="font-semibold text-foreground flex items-center gap-2">
                <User className="h-4 w-4 text-accent" />
                {user?.name || "User"}
              </p>
            </div>

            <div className="rounded-lg bg-muted/50 p-4">
              <p className="text-sm text-muted-foreground mb-1">Email</p>
              <p className="font-semibold text-foreground flex items-center gap-2">
                <Mail className="h-4 w-4 text-accent" />
                {user?.email || "Not provided"}
              </p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg bg-muted/50 p-3 text-center">
              <p className="text-sm text-muted-foreground">Account Status</p>
              <p className="font-semibold text-green-400 mt-1">Active</p>
            </div>
            <div className="rounded-lg bg-muted/50 p-3 text-center">
              <p className="text-sm text-muted-foreground">Member Since</p>
              <p className="font-semibold text-foreground mt-1">2026</p>
            </div>
          </div>

          {/* Logout Button */}
          <motion.button
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            onClick={onLogout}
            className="w-full rounded-lg bg-destructive/20 px-4 py-3 font-medium text-destructive hover:bg-destructive/30 transition-colors flex items-center justify-center gap-2"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </motion.button>
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}
