import { motion, AnimatePresence } from "framer-motion";
import { useLocation } from "wouter";
import {
  Home,
  MessageSquare,
  Target,
  BookOpen,
  Calendar,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";

interface SidebarProps {
  isOpen: boolean;
  onClose?: () => void;
}

const navItems = [
  { href: "/", label: "Dashboard", icon: Home },
  { href: "/chat", label: "AI Chat", icon: MessageSquare },
  { href: "/goals", label: "Goals", icon: Target },
  { href: "/workspace", label: "Workspace", icon: BookOpen },
  { href: "/notes", label: "Notes", icon: BookOpen },
  { href: "/calendar", label: "Calendar", icon: Calendar },
];

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const [location] = useLocation();

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 z-30 bg-black/50 backdrop-blur-sm lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: isOpen ? 0 : -280 }}
        transition={{ duration: 0.3 }}
        className="fixed left-0 top-0 z-40 h-screen w-64 border-r border-border/50 bg-background/95 backdrop-blur-xl pt-20 lg:static lg:translate-x-0"
      >
        {/* Close button for mobile */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          className="absolute right-4 top-4 rounded-lg p-2 hover:bg-muted lg:hidden"
        >
          <X className="h-5 w-5" />
        </motion.button>

        {/* Navigation */}
        <nav className="space-y-2 px-4 py-6">
          {navItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = location === item.href;

            return (
              <motion.div
                key={item.href}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
              >
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={`w-full justify-start gap-3 transition-smooth ${
                    isActive ? "neon-glow" : ""
                  }`}
                  asChild
                >
                  <a href={item.href} onClick={onClose}>
                    <Icon className="h-5 w-5" />
                    <span>{item.label}</span>
                  </a>
                </Button>
              </motion.div>
            );
          })}
        </nav>

        {/* Bottom section */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="absolute bottom-0 left-0 right-0 border-t border-border/50 bg-gradient-to-t from-background to-transparent p-4"
        >
          <div className="rounded-lg glassmorphism-dark p-3 text-xs text-muted-foreground">
            <p className="font-semibold text-foreground mb-1">Titan.Ai</p>
            <p>Your AI-powered life management platform</p>
          </div>
        </motion.div>
      </motion.aside>
    </>
  );
}
