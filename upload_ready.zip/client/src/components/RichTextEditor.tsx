import { motion } from "framer-motion";
import { useState } from "react";
import { Bold, Italic, List, ListOrdered, Heading2, Code } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
}

export function RichTextEditor({
  value,
  onChange,
  placeholder = "Start typing...",
}: RichTextEditorProps) {
  const [selectedText, setSelectedText] = useState("");

  const applyFormatting = (before: string, after: string = "") => {
    const textarea = document.querySelector("textarea") as HTMLTextAreaElement;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selected = value.substring(start, end);

    if (!selected) {
      onChange(value.substring(0, start) + before + value.substring(end));
    } else {
      const newValue =
        value.substring(0, start) +
        before +
        selected +
        after +
        value.substring(end);
      onChange(newValue);
    }
  };

  const formatButtons = [
    {
      icon: Bold,
      label: "Bold",
      onClick: () => applyFormatting("**", "**"),
    },
    {
      icon: Italic,
      label: "Italic",
      onClick: () => applyFormatting("*", "*"),
    },
    {
      icon: Code,
      label: "Code",
      onClick: () => applyFormatting("`", "`"),
    },
    {
      icon: Heading2,
      label: "Heading",
      onClick: () => applyFormatting("## "),
    },
    {
      icon: List,
      label: "Bullet List",
      onClick: () => applyFormatting("- "),
    },
    {
      icon: ListOrdered,
      label: "Numbered List",
      onClick: () => applyFormatting("1. "),
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-lg glassmorphism-dark p-4"
    >
      {/* Toolbar */}
      <div className="flex flex-wrap gap-2 mb-4 pb-4 border-b border-border/50">
        {formatButtons.map((btn) => {
          const Icon = btn.icon;
          return (
            <motion.button
              key={btn.label}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={btn.onClick}
              title={btn.label}
              className="rounded-lg p-2 hover:bg-muted transition-colors"
            >
              <Icon className="h-4 w-4 text-muted-foreground hover:text-foreground" />
            </motion.button>
          );
        })}
      </div>

      {/* Editor */}
      <Textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="min-h-64 resize-none font-mono text-sm"
      />

      {/* Preview hint */}
      <div className="mt-3 text-xs text-muted-foreground">
        💡 Supports Markdown formatting. Use **bold**, *italic*, `code`, etc.
      </div>
    </motion.div>
  );
}
