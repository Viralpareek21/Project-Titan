import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { Target, Plus, Trash2, Edit2, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";

interface Goal {
  id: number;
  title: string;
  description?: string;
  category: "personal" | "health" | "career" | "education" | "finance";
  progress: number;
  status: "active" | "completed" | "paused" | "archived";
  deadline?: Date;
}

// Mock data
const mockGoals: Goal[] = [
  {
    id: 1,
    title: "Complete Q4 Project",
    description: "Finish the main project deliverables",
    category: "career",
    progress: 65,
    status: "active",
    deadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
  },
  {
    id: 2,
    title: "Morning Workout Routine",
    description: "Exercise 5 times a week",
    category: "health",
    progress: 80,
    status: "active",
  },
  {
    id: 3,
    title: "Learn React Advanced",
    description: "Master hooks and performance optimization",
    category: "education",
    progress: 45,
    status: "active",
  },
  {
    id: 4,
    title: "Save for Vacation",
    description: "Save $5000 for summer vacation",
    category: "finance",
    progress: 30,
    status: "active",
  },
];

const categoryColors: Record<string, string> = {
  personal: "bg-blue-500/20 text-blue-400",
  health: "bg-green-500/20 text-green-400",
  career: "bg-purple-500/20 text-purple-400",
  education: "bg-yellow-500/20 text-yellow-400",
  finance: "bg-pink-500/20 text-pink-400",
};

const coachNudges = [
  "You're crushing it! Keep up the momentum on your career goals.",
  "Your health routine is looking strong. Stay consistent!",
  "Consider breaking down larger goals into smaller milestones.",
  "You've completed 3 goals this month. Amazing progress!",
  "Time to review your goals and adjust deadlines if needed.",
];

export default function Goals() {
  const [goals, setGoals] = useState<Goal[]>(mockGoals);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingGoal, setEditingGoal] = useState<Goal | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    category: "personal" as const,
  });

  const handleAddGoal = () => {
    if (!formData.title.trim()) return;

    const newGoal: Goal = {
      id: Math.max(...goals.map((g) => g.id), 0) + 1,
      title: formData.title,
      description: formData.description,
      category: formData.category,
      progress: 0,
      status: "active",
    };

    setGoals([newGoal, ...goals]);
    setFormData({ title: "", description: "", category: "personal" });
    setIsDialogOpen(false);
  };

  const handleDeleteGoal = (id: number) => {
    setGoals(goals.filter((g) => g.id !== id));
  };

  const handleUpdateProgress = (id: number, progress: number) => {
    setGoals(
      goals.map((g) =>
        g.id === id
          ? {
              ...g,
              progress,
              status: progress === 100 ? "completed" : g.status,
            }
          : g
      )
    );
  };

  const activeGoals = goals.filter((g) => g.status === "active");
  const completedGoals = goals.filter((g) => g.status === "completed");
  const randomNudge = coachNudges[Math.floor(Math.random() * coachNudges.length)];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/50 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground flex items-center gap-3 mb-2">
              <Target className="h-8 w-8 text-accent" />
              Goals & Coaching
            </h1>
            <p className="text-muted-foreground">
              Track your progress and get AI-powered coaching nudges
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button className="gap-2 neon-glow">
                  <Plus className="h-4 w-4" />
                  New Goal
                </Button>
              </motion.button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Goal</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Goal title"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                />
                <Input
                  placeholder="Description (optional)"
                  value={formData.description}
                  onChange={(e) =>
                    setFormData({ ...formData, description: e.target.value })
                  }
                />
                <Select
                  value={formData.category}
                  onValueChange={(value: any) =>
                    setFormData({ ...formData, category: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="personal">Personal</SelectItem>
                    <SelectItem value="health">Health</SelectItem>
                    <SelectItem value="career">Career</SelectItem>
                    <SelectItem value="education">Education</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                  </SelectContent>
                </Select>
                <Button onClick={handleAddGoal} className="w-full neon-glow">
                  Create Goal
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>

      {/* Coach Nudge */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mb-8 rounded-lg glassmorphism-dark p-6 border-l-4 border-accent neon-glow-sm"
      >
        <div className="flex items-start gap-4">
          <div className="rounded-lg bg-accent/20 p-3 flex-shrink-0">
            <Zap className="h-6 w-6 text-accent" />
          </div>
          <div>
            <h3 className="font-semibold text-foreground mb-1">Coach Nudge</h3>
            <p className="text-muted-foreground">{randomNudge}</p>
          </div>
        </div>
      </motion.div>

      {/* Stats */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="mb-8 grid gap-4 sm:grid-cols-3"
      >
        <div className="rounded-lg glassmorphism-dark p-4">
          <p className="text-sm text-muted-foreground mb-1">Active Goals</p>
          <p className="text-3xl font-bold text-accent">{activeGoals.length}</p>
        </div>
        <div className="rounded-lg glassmorphism-dark p-4">
          <p className="text-sm text-muted-foreground mb-1">Completed</p>
          <p className="text-3xl font-bold text-green-400">{completedGoals.length}</p>
        </div>
        <div className="rounded-lg glassmorphism-dark p-4">
          <p className="text-sm text-muted-foreground mb-1">Avg Progress</p>
          <p className="text-3xl font-bold text-blue-400">
            {Math.round(
              goals.reduce((sum, g) => sum + g.progress, 0) / goals.length
            )}
            %
          </p>
        </div>
      </motion.div>

      {/* Goals List */}
      <motion.div
        variants={{
          hidden: { opacity: 0 },
          visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1 },
          },
        }}
        initial="hidden"
        animate="visible"
        className="space-y-4"
      >
        <AnimatePresence>
          {activeGoals.map((goal, index) => (
            <motion.div
              key={goal.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              transition={{ delay: index * 0.1 }}
              className="rounded-lg glassmorphism-dark p-6 hover:bg-white/15 transition-colors"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-foreground">
                      {goal.title}
                    </h3>
                    <Badge className={categoryColors[goal.category]}>
                      {goal.category}
                    </Badge>
                  </div>
                  {goal.description && (
                    <p className="text-sm text-muted-foreground">
                      {goal.description}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => handleDeleteGoal(goal.id)}
                    className="rounded-lg p-2 hover:bg-destructive/20"
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </motion.button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-foreground">
                    Progress
                  </span>
                  <span className="text-sm text-muted-foreground">
                    {goal.progress}%
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <Progress value={goal.progress} className="flex-1" />
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={goal.progress}
                    onChange={(e) =>
                      handleUpdateProgress(goal.id, parseInt(e.target.value))
                    }
                    className="w-24 cursor-pointer"
                  />
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      {goals.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <Target className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
          <p className="text-muted-foreground">
            No goals yet. Create your first goal to get started!
          </p>
        </motion.div>
      )}
    </div>
  );
}
