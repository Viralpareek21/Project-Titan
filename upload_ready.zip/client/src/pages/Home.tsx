import { useAuth } from "@/_core/hooks/useAuth";
import { motion } from "framer-motion";
import { Calendar, Target, BookOpen, Zap, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { getLoginUrl } from "@/const";
import { useMemo } from "react";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

function getTimeBasedGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}

function DashboardWidget({
  icon: Icon,
  title,
  description,
  href,
}: {
  icon: React.ComponentType<{ className: string }>;
  title: string;
  description: string;
  href: string;
}) {
  return (
    <motion.a
      href={href}
      variants={itemVariants}
      whileHover={{ scale: 1.02, y: -5 }}
      whileTap={{ scale: 0.98 }}
      className="group relative overflow-hidden rounded-lg glassmorphism-dark p-6 transition-all duration-300 cursor-pointer"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-accent/0 to-accent/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

      <div className="relative z-10">
        <div className="mb-4 inline-flex rounded-lg bg-accent/20 p-3 neon-glow-sm">
          <Icon className="h-6 w-6 text-accent" />
        </div>
        <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </motion.a>
  );
}

// Mock data for upcoming events
const mockUpcomingEvents = [
  {
    id: 1,
    title: "Team Standup",
    time: "10:00 AM",
    color: "bg-blue-500/20",
  },
  {
    id: 2,
    title: "Project Review",
    time: "2:00 PM",
    color: "bg-purple-500/20",
  },
  {
    id: 3,
    title: "Study Session",
    time: "4:30 PM",
    color: "bg-green-500/20",
  },
];

// Mock data for active goals
const mockActiveGoals = [
  {
    id: 1,
    title: "Complete Q4 Project",
    progress: 65,
    category: "career",
  },
  {
    id: 2,
    title: "Morning Workout Routine",
    progress: 80,
    category: "health",
  },
  {
    id: 3,
    title: "Learn React Advanced",
    progress: 45,
    category: "education",
  },
];

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const greeting = useMemo(() => getTimeBasedGreeting(), []);

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-background/50">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="max-w-md text-center"
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
            className="mx-auto mb-6 h-20 w-20 rounded-full bg-gradient-to-br from-accent to-accent/50 flex items-center justify-center neon-glow"
          >
            <svg
              viewBox="0 0 24 24"
              className="h-10 w-10 text-accent-foreground"
              fill="currentColor"
            >
              <circle cx="12" cy="12" r="10" opacity="0.3" />
              <circle cx="12" cy="12" r="6" opacity="0.6" />
              <circle cx="12" cy="12" r="2" />
            </svg>
          </motion.div>

          <h1 className="text-3xl font-bold text-foreground mb-3">
            Welcome to Titan.Ai
          </h1>
          <p className="text-muted-foreground mb-8">
            Your AI-powered personal productivity platform. Manage your goals, studies, and business all in one place.
          </p>

          <Button asChild size="lg" className="neon-glow">
            <a href={getLoginUrl()}>Get Started</a>
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/50 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <h1 className="text-4xl font-bold text-foreground mb-2">
          {greeting}, {user?.name || "User"}! 👋
        </h1>
        <p className="text-muted-foreground">
          {new Date().toLocaleDateString("en-US", {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </p>
      </motion.div>

      {/* Quick Stats */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4"
      >
        {[
          { label: "Active Goals", value: "5", icon: Target },
          { label: "Upcoming Events", value: "3", icon: Calendar },
          { label: "Study Sessions", value: "12", icon: BookOpen },
          { label: "Productivity Score", value: "87%", icon: Zap },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <motion.div
              key={stat.label}
              variants={itemVariants}
              className="rounded-lg glassmorphism-dark p-4 neon-glow-sm"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {stat.value}
                  </p>
                </div>
                <div className="rounded-lg bg-accent/20 p-3">
                  <Icon className="h-6 w-6 text-accent" />
                </div>
              </div>
            </motion.div>
          );
        })}
      </motion.div>

      {/* Main content grid */}
      <div className="grid gap-6 lg:grid-cols-3 mb-8">
        {/* Left column: Upcoming events and goals */}
        <div className="lg:col-span-2 space-y-6">
          {/* Upcoming Events */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="rounded-lg glassmorphism-dark p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
                <Calendar className="h-5 w-5 text-accent" />
                Upcoming Events
              </h2>
              <Button variant="ghost" size="sm" asChild>
                <a href="/calendar" className="gap-1">
                  View all <ChevronRight className="h-4 w-4" />
                </a>
              </Button>
            </div>
            <div className="space-y-3">
              {mockUpcomingEvents.map((event, index) => (
                <motion.div
                  key={event.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.4 + index * 0.1 }}
                  className={`flex items-center gap-4 rounded-lg p-3 ${event.color}`}
                >
                  <div className="h-10 w-10 rounded-lg bg-accent/30 flex items-center justify-center">
                    <Calendar className="h-5 w-5 text-accent" />
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{event.title}</p>
                    <p className="text-sm text-muted-foreground">{event.time}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Active Goals */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="rounded-lg glassmorphism-dark p-6"
          >
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-foreground flex items-center gap-2">
                <Target className="h-5 w-5 text-accent" />
                Active Goals
              </h2>
              <Button variant="ghost" size="sm" asChild>
                <a href="/goals" className="gap-1">
                  Manage <ChevronRight className="h-4 w-4" />
                </a>
              </Button>
            </div>
            <div className="space-y-4">
              {mockActiveGoals.map((goal, index) => (
                <motion.div
                  key={goal.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.5 + index * 0.1 }}
                >
                  <div className="flex items-center justify-between mb-2">
                    <p className="font-medium text-foreground">{goal.title}</p>
                    <span className="text-sm text-muted-foreground">{goal.progress}%</span>
                  </div>
                  <Progress value={goal.progress} className="h-2" />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Right column: Quick actions */}
        <div className="space-y-6">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-3"
          >
            <DashboardWidget
              icon={Calendar}
              title="Calendar"
              description="View and manage your events"
              href="/calendar"
            />
            <DashboardWidget
              icon={Target}
              title="Goals"
              description="Track your progress"
              href="/goals"
            />
            <DashboardWidget
              icon={BookOpen}
              title="Workspace"
              description="Study or work mode"
              href="/workspace"
            />
            <DashboardWidget
              icon={Zap}
              title="AI Chat"
              description="Get insights & motivation"
              href="/chat"
            />
          </motion.div>
        </div>
      </div>

      {/* Recent activity section */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="rounded-lg glassmorphism-dark p-6"
      >
        <h2 className="text-xl font-semibold text-foreground mb-4">
          Recent Activity
        </h2>
        <div className="space-y-3">
          {[
            "Completed morning study session",
            "Updated Q4 business goals",
            "Scheduled meeting with team",
          ].map((activity, index) => (
            <motion.div
              key={activity}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 + index * 0.1 }}
              className="flex items-center gap-3 text-sm text-muted-foreground"
            >
              <div className="h-2 w-2 rounded-full bg-accent" />
              {activity}
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
