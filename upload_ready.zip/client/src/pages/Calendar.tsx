import { motion } from "framer-motion";
import { useState } from "react";
import { Calendar as CalendarIcon, Plus, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

interface CalendarEvent {
  id: number;
  title: string;
  date: Date;
  time: string;
  color: string;
}

// Mock events
const mockEvents: CalendarEvent[] = [
  {
    id: 1,
    title: "Team Standup",
    date: new Date(2026, 5, 15),
    time: "10:00 AM",
    color: "bg-blue-500/20",
  },
  {
    id: 2,
    title: "Project Review",
    date: new Date(2026, 5, 15),
    time: "2:00 PM",
    color: "bg-purple-500/20",
  },
  {
    id: 3,
    title: "Study Session",
    date: new Date(2026, 5, 16),
    time: "4:30 PM",
    color: "bg-green-500/20",
  },
  {
    id: 4,
    title: "Client Meeting",
    date: new Date(2026, 5, 18),
    time: "11:00 AM",
    color: "bg-orange-500/20",
  },
];

const daysOfWeek = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const monthNames = [
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date(2026, 5, 15));
  const [events, setEvents] = useState<CalendarEvent[]>(mockEvents);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    time: "10:00 AM",
  });

  const getDaysInMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date: Date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const handleAddEvent = () => {
    if (!formData.title.trim()) return;

    const newEvent: CalendarEvent = {
      id: Math.max(...events.map((e) => e.id), 0) + 1,
      title: formData.title,
      date: currentDate,
      time: formData.time,
      color: "bg-blue-500/20",
    };

    setEvents([...events, newEvent]);
    setFormData({ title: "", time: "10:00 AM" });
    setIsDialogOpen(false);
  };

  const handlePrevMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() - 1)
    );
  };

  const handleNextMonth = () => {
    setCurrentDate(
      new Date(currentDate.getFullYear(), currentDate.getMonth() + 1)
    );
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const calendarDays = Array(firstDay)
    .fill(null)
    .concat(Array.from({ length: daysInMonth }, (_, i) => i + 1));

  const getEventsForDate = (day: number) => {
    return events.filter(
      (e) =>
        e.date.getDate() === day &&
        e.date.getMonth() === currentDate.getMonth() &&
        e.date.getFullYear() === currentDate.getFullYear()
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/50 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-bold text-foreground flex items-center gap-3 mb-2">
              <CalendarIcon className="h-8 w-8 text-accent" />
              Calendar
            </h1>
            <p className="text-muted-foreground">
              Manage your events and schedule
            </p>
          </div>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button className="gap-2 neon-glow">
                  <Plus className="h-4 w-4" />
                  Add Event
                </Button>
              </motion.button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add Event</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Event title"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                />
                <Input
                  type="time"
                  value={formData.time}
                  onChange={(e) =>
                    setFormData({ ...formData, time: e.target.value })
                  }
                />
                <Button onClick={handleAddEvent} className="w-full neon-glow">
                  Add Event
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>

      {/* Calendar Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-lg glassmorphism-dark p-6"
      >
        {/* Month Navigation */}
        <div className="flex items-center justify-between mb-6">
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handlePrevMonth}
            className="rounded-lg p-2 hover:bg-muted"
          >
            <ChevronLeft className="h-5 w-5" />
          </motion.button>
          <h2 className="text-2xl font-bold text-foreground">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h2>
          <motion.button
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
            onClick={handleNextMonth}
            className="rounded-lg p-2 hover:bg-muted"
          >
            <ChevronRight className="h-5 w-5" />
          </motion.button>
        </div>

        {/* Day Headers */}
        <div className="grid grid-cols-7 gap-2 mb-4">
          {daysOfWeek.map((day) => (
            <div
              key={day}
              className="text-center font-semibold text-muted-foreground py-2"
            >
              {day}
            </div>
          ))}
        </div>

        {/* Calendar Days */}
        <div className="grid grid-cols-7 gap-2">
          {calendarDays.map((day, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: index * 0.02 }}
              className={`min-h-24 rounded-lg p-2 ${
                day
                  ? "bg-muted/50 hover:bg-muted/70 transition-colors cursor-pointer"
                  : "bg-transparent"
              }`}
            >
              {day && (
                <div>
                  <p className="font-semibold text-foreground mb-2">{day}</p>
                  <div className="space-y-1">
                    {getEventsForDate(day).map((event) => (
                      <div
                        key={event.id}
                        className={`text-xs rounded px-2 py-1 ${event.color} text-foreground truncate`}
                      >
                        {event.title}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Upcoming Events List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="mt-8 rounded-lg glassmorphism-dark p-6"
      >
        <h3 className="text-xl font-semibold text-foreground mb-4">
          Upcoming Events
        </h3>
        <div className="space-y-3">
          {events
            .sort((a, b) => a.date.getTime() - b.date.getTime())
            .slice(0, 5)
            .map((event, index) => (
              <motion.div
                key={event.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.5 + index * 0.1 }}
                className={`flex items-center gap-4 rounded-lg p-3 ${event.color}`}
              >
                <div className="h-10 w-10 rounded-lg bg-accent/30 flex items-center justify-center flex-shrink-0">
                  <CalendarIcon className="h-5 w-5 text-accent" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-foreground">{event.title}</p>
                  <p className="text-sm text-muted-foreground">
                    {event.date.toLocaleDateString()} at {event.time}
                  </p>
                </div>
              </motion.div>
            ))}
        </div>
      </motion.div>
    </div>
  );
}
