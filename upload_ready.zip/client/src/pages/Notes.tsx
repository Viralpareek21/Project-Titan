import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { FileText, Plus, Trash2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { RichTextEditor } from "@/components/RichTextEditor";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Streamdown } from "streamdown";

interface Note {
  id: number;
  title: string;
  content: string;
  mode: "study" | "business";
  updatedAt: Date;
}

// Mock data
const mockNotes: Note[] = [
  {
    id: 1,
    title: "React Hooks Guide",
    content: "# React Hooks\n\n## useState\nManages component state...\n\n## useEffect\nHandles side effects...",
    mode: "study",
    updatedAt: new Date(),
  },
  {
    id: 2,
    title: "Q4 Project Plan",
    content: "## Project Milestones\n\n1. **Phase 1**: Design\n2. **Phase 2**: Development\n3. **Phase 3**: Testing",
    mode: "business",
    updatedAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
];

export default function Notes() {
  const [notes, setNotes] = useState<Note[]>(mockNotes);
  const [selectedNote, setSelectedNote] = useState<Note | null>(mockNotes[0]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({ title: "", mode: "study" as "study" | "business" });

  const handleAddNote = () => {
    if (!formData.title.trim()) return;

    const newNote: Note = {
      id: Math.max(...notes.map((n) => n.id), 0) + 1,
      title: formData.title,
      content: "",
      mode: formData.mode,
      updatedAt: new Date(),
    };

    setNotes([newNote, ...notes]);
    setSelectedNote(newNote);
    setFormData({ title: "", mode: "study" as "study" | "business" });
    setIsDialogOpen(false);
  };

  const handleUpdateNote = (id: number, content: string) => {
    setNotes(
      notes.map((n) =>
        n.id === id ? { ...n, content, updatedAt: new Date() } : n
      )
    );
    if (selectedNote?.id === id) {
      setSelectedNote({ ...selectedNote, content });
    }
  };

  const handleDeleteNote = (id: number) => {
    setNotes(notes.filter((n) => n.id !== id));
    if (selectedNote?.id === id) {
      setSelectedNote(notes.find((n) => n.id !== id) || null);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/50 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between">
          <h1 className="text-4xl font-bold text-foreground flex items-center gap-3 mb-2">
            <FileText className="h-8 w-8 text-accent" />
            Notes
          </h1>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Button className="gap-2 neon-glow">
                  <Plus className="h-4 w-4" />
                  New Note
                </Button>
              </motion.button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Note</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Note title"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                />
                <select
                  value={formData.mode}
                  onChange={(e) => {
                    const mode = e.target.value as "study" | "business";
                    setFormData({ ...formData, mode });
                  }}
                  className="w-full rounded-lg bg-muted px-3 py-2 text-foreground"
                >
                  <option value="study">Study Mode</option>
                  <option value="business">Business Mode</option>
                </select>
                <Button onClick={handleAddNote} className="w-full neon-glow">
                  Create Note
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </motion.div>

      {/* Main content */}
      <div className="grid gap-6 lg:grid-cols-4">
        {/* Notes List */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-1"
        >
          <div className="rounded-lg glassmorphism-dark p-4 space-y-2">
            <h3 className="font-semibold text-foreground mb-4">All Notes</h3>
            <AnimatePresence>
              {notes.map((note, index) => (
                <motion.div
                  key={note.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.05 }}
                  onClick={() => setSelectedNote(note)}
                  className={`group cursor-pointer rounded-lg p-3 transition-all ${
                    selectedNote?.id === note.id
                      ? "bg-accent/20 border border-accent"
                      : "bg-muted/50 hover:bg-muted"
                  }`}
                >
                  <p className="font-medium text-foreground text-sm truncate">
                    {note.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {note.mode === "study" ? "📚 Study" : "💼 Business"}
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDeleteNote(note.id);
                    }}
                    className="opacity-0 group-hover:opacity-100 transition-opacity mt-2"
                  >
                    <Trash2 className="h-3 w-3 text-destructive" />
                  </motion.button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </motion.div>

        {/* Editor */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="lg:col-span-3"
        >
          {selectedNote ? (
            <div className="space-y-4">
              <div className="rounded-lg glassmorphism-dark p-4">
                <Input
                  value={selectedNote.title}
                  onChange={(e) =>
                    setSelectedNote({
                      ...selectedNote,
                      title: e.target.value,
                    })
                  }
                  className="text-2xl font-bold"
                />
              </div>

              <RichTextEditor
                value={selectedNote.content}
                onChange={(content) => handleUpdateNote(selectedNote.id, content)}
                placeholder="Start writing your note..."
              />

              {/* Preview */}
              <div className="rounded-lg glassmorphism-dark p-6">
                <h3 className="text-lg font-semibold text-foreground mb-4">
                  Preview
                </h3>
                <div className="prose prose-invert max-w-none">
                  <Streamdown className="text-foreground">
                    {selectedNote.content || "*No content yet*"}
                  </Streamdown>
                </div>
              </div>

              {/* Last updated */}
              <p className="text-xs text-muted-foreground">
                Last updated: {selectedNote.updatedAt.toLocaleString()}
              </p>
            </div>
          ) : (
            <div className="rounded-lg glassmorphism-dark p-12 text-center">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No note selected</p>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
