import { motion, AnimatePresence } from "framer-motion";
import { useState } from "react";
import { BookOpen, Briefcase, Plus, Trash2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Mode = "study" | "business";

interface Flashcard {
  id: number;
  question: string;
  answer: string;
  category: string;
}

interface KanbanCard {
  id: number;
  title: string;
  status: "todo" | "in_progress" | "review" | "done";
}

// Mock data
const mockFlashcards: Flashcard[] = [
  {
    id: 1,
    question: "What is React?",
    answer: "React is a JavaScript library for building user interfaces with components.",
    category: "React",
  },
  {
    id: 2,
    question: "What are hooks?",
    answer: "Hooks are functions that let you use state and other React features in functional components.",
    category: "React",
  },
  {
    id: 3,
    question: "What is JSX?",
    answer: "JSX is a syntax extension for JavaScript that looks like HTML and is used in React.",
    category: "React",
  },
];

const mockKanbanCards: KanbanCard[] = [
  { id: 1, title: "Design homepage", status: "todo" },
  { id: 2, title: "Setup database", status: "in_progress" },
  { id: 3, title: "API integration", status: "review" },
  { id: 4, title: "Testing", status: "done" },
];

export default function Workspace() {
  const [mode, setMode] = useState<Mode>("study");
  const [flashcards, setFlashcards] = useState<Flashcard[]>(mockFlashcards);
  const [kanbanCards, setKanbanCards] = useState<KanbanCard[]>(mockKanbanCards);
  const [currentFlashcardIndex, setCurrentFlashcardIndex] = useState(0);
  const [showAnswer, setShowAnswer] = useState(false);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    question: "",
    answer: "",
    category: "General",
  });

  const handleAddFlashcard = () => {
    if (!formData.question.trim() || !formData.answer.trim()) return;

    const newCard: Flashcard = {
      id: Math.max(...flashcards.map((c) => c.id), 0) + 1,
      ...formData,
    };

    setFlashcards([...flashcards, newCard]);
    setFormData({ question: "", answer: "", category: "General" });
    setIsDialogOpen(false);
  };

  const handleDeleteFlashcard = (id: number) => {
    setFlashcards(flashcards.filter((c) => c.id !== id));
    if (currentFlashcardIndex >= flashcards.length - 1) {
      setCurrentFlashcardIndex(Math.max(0, currentFlashcardIndex - 1));
    }
  };

  const handleUpdateKanbanCard = (id: number, newStatus: KanbanCard["status"]) => {
    setKanbanCards(
      kanbanCards.map((c) =>
        c.id === id ? { ...c, status: newStatus } : c
      )
    );
  };

  const currentFlashcard = flashcards[currentFlashcardIndex];

  const kanbanColumns = [
    { status: "todo" as const, label: "To Do", color: "bg-blue-500/20" },
    { status: "in_progress" as const, label: "In Progress", color: "bg-purple-500/20" },
    { status: "review" as const, label: "Review", color: "bg-yellow-500/20" },
    { status: "done" as const, label: "Done", color: "bg-green-500/20" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-background/50 p-4 sm:p-6 lg:p-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="mb-8"
      >
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-4xl font-bold text-foreground flex items-center gap-3">
            <BookOpen className="h-8 w-8 text-accent" />
            Workspace
          </h1>
        </div>

        {/* Mode Toggle */}
        <div className="flex gap-3">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {
              setMode("study");
              setShowAnswer(false);
            }}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 transition-all ${
              mode === "study"
                ? "bg-accent text-accent-foreground neon-glow"
                : "bg-muted text-foreground hover:bg-muted/80"
            }`}
          >
            <BookOpen className="h-4 w-4" />
            Study Mode
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setMode("business")}
            className={`flex items-center gap-2 rounded-lg px-4 py-2 transition-all ${
              mode === "business"
                ? "bg-accent text-accent-foreground neon-glow"
                : "bg-muted text-foreground hover:bg-muted/80"
            }`}
          >
            <Briefcase className="h-4 w-4" />
            Business Mode
          </motion.button>
        </div>
      </motion.div>

      <AnimatePresence mode="wait">
        {/* Study Mode */}
        {mode === "study" && (
          <motion.div
            key="study"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {/* Flashcard Viewer */}
            {currentFlashcard ? (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="rounded-lg glassmorphism-dark p-8 min-h-64 flex flex-col justify-center items-center text-center cursor-pointer neon-glow"
                onClick={() => setShowAnswer(!showAnswer)}
              >
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.2 }}
                >
                  <p className="text-sm text-muted-foreground mb-4">
                    {currentFlashcardIndex + 1} / {flashcards.length}
                  </p>
                  <h2 className="text-3xl font-bold text-foreground mb-6">
                    {currentFlashcard.question}
                  </h2>
                  <AnimatePresence>
                    {showAnswer && (
                      <motion.div
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                      >
                        <div className="bg-accent/20 rounded-lg p-4 border border-accent/50">
                          <p className="text-lg text-foreground">
                            {currentFlashcard.answer}
                          </p>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                  <p className="text-sm text-muted-foreground mt-6">
                    Click to {showAnswer ? "hide" : "reveal"} answer
                  </p>
                </motion.div>
              </motion.div>
            ) : (
              <div className="rounded-lg glassmorphism-dark p-8 text-center">
                <p className="text-muted-foreground">No flashcards yet</p>
              </div>
            )}

            {/* Navigation */}
            {flashcards.length > 0 && (
              <div className="flex gap-3 justify-center">
                <Button
                  variant="outline"
                  onClick={() => setCurrentFlashcardIndex(Math.max(0, currentFlashcardIndex - 1))}
                  disabled={currentFlashcardIndex === 0}
                >
                  Previous
                </Button>
                <Button
                  variant="outline"
                  onClick={() =>
                    setCurrentFlashcardIndex(
                      Math.min(flashcards.length - 1, currentFlashcardIndex + 1)
                    )
                  }
                  disabled={currentFlashcardIndex === flashcards.length - 1}
                >
                  Next
                </Button>
              </div>
            )}

            {/* Flashcard List */}
            <div className="rounded-lg glassmorphism-dark p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-foreground">
                  Flashcards
                </h3>
                <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                  <DialogTrigger asChild>
                    <Button size="sm" className="gap-2">
                      <Plus className="h-4 w-4" />
                      New Card
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Create Flashcard</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Textarea
                        placeholder="Question"
                        value={formData.question}
                        onChange={(e) =>
                          setFormData({ ...formData, question: e.target.value })
                        }
                      />
                      <Textarea
                        placeholder="Answer"
                        value={formData.answer}
                        onChange={(e) =>
                          setFormData({ ...formData, answer: e.target.value })
                        }
                      />
                      <Input
                        placeholder="Category"
                        value={formData.category}
                        onChange={(e) =>
                          setFormData({ ...formData, category: e.target.value })
                        }
                      />
                      <Button onClick={handleAddFlashcard} className="w-full">
                        Create
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
              </div>
              <div className="space-y-2">
                {flashcards.map((card, index) => (
                  <motion.div
                    key={card.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className={`flex items-center justify-between p-3 rounded-lg ${
                      index === currentFlashcardIndex
                        ? "bg-accent/20 border border-accent"
                        : "bg-muted/50"
                    }`}
                  >
                    <div className="flex-1 cursor-pointer" onClick={() => setCurrentFlashcardIndex(index)}>
                      <p className="font-medium text-foreground">{card.question}</p>
                      <p className="text-xs text-muted-foreground">{card.category}</p>
                    </div>
                    <motion.button
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={() => handleDeleteFlashcard(card.id)}
                      className="rounded-lg p-2 hover:bg-destructive/20"
                    >
                      <Trash2 className="h-4 w-4 text-destructive" />
                    </motion.button>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Business Mode - Kanban */}
        {mode === "business" && (
          <motion.div
            key="business"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {kanbanColumns.map((column) => (
                <motion.div
                  key={column.status}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 }}
                  className="rounded-lg glassmorphism-dark p-4"
                >
                  <h3 className={`font-semibold text-foreground mb-4 px-2 py-1 rounded ${column.color}`}>
                    {column.label}
                  </h3>
                  <div className="space-y-3">
                    {kanbanCards
                      .filter((c) => c.status === column.status)
                      .map((card, index) => (
                        <motion.div
                          key={card.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: index * 0.05 }}
                          className="bg-muted/50 rounded-lg p-3 hover:bg-muted/70 transition-colors cursor-move group"
                        >
                          <p className="font-medium text-foreground text-sm">
                            {card.title}
                          </p>
                          <div className="flex gap-2 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            {kanbanColumns.map((col) => (
                              col.status !== column.status && (
                                <button
                                  key={col.status}
                                  onClick={() =>
                                    handleUpdateKanbanCard(card.id, col.status)
                                  }
                                  className="text-xs px-2 py-1 rounded bg-accent/20 text-accent hover:bg-accent/30"
                                >
                                  {col.label}
                                </button>
                              )
                            ))}
                          </div>
                        </motion.div>
                      ))}
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
