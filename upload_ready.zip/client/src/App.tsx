import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { Navbar } from "./components/Navbar";
import { Sidebar } from "./components/Sidebar";
import { FloatingChatSidebar } from "./components/FloatingChatSidebar";
import { LayoutWrapper } from "./components/LayoutWrapper";
import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { useAuth } from "./_core/hooks/useAuth";
import { getLoginUrl } from "./const";

// Pages
import Home from "./pages/Home";
import Chat from "./pages/Chat";
import Goals from "./pages/Goals";
import Workspace from "./pages/Workspace";
import Calendar from "./pages/Calendar";
import Notes from "./pages/Notes";

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-accent"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    window.location.href = getLoginUrl();
    return null;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/chat" component={() => <ProtectedRoute component={Chat} />} />
      <Route path="/goals" component={() => <ProtectedRoute component={Goals} />} />
      <Route path="/workspace" component={() => <ProtectedRoute component={Workspace} />} />
      <Route path="/calendar" component={() => <ProtectedRoute component={Calendar} />} />
      <Route path="/notes" component={() => <ProtectedRoute component={Notes} />} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function AppLayout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen flex-col lg:flex-row">
      <Navbar onMenuToggle={() => setSidebarOpen(!sidebarOpen)} />
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <main className="flex-1 overflow-hidden pt-16 lg:pt-0">
        <div className="h-full overflow-auto">
          <AnimatePresence mode="wait">
            <LayoutWrapper>
              <Router />
            </LayoutWrapper>
          </AnimatePresence>
        </div>
      </main>
      <FloatingChatSidebar />
    </div>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <AppLayout />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
