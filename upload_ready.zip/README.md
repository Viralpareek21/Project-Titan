# Project Titan.Ai

A production-ready, AI-powered personal productivity platform built with Next.js, React, Express, and Manus OAuth. Manage your life, goals, studies, and business work all in one sleek, dark-themed application.

## Features

- **Unified Life Dashboard** — Daily overview with quick stats, upcoming events, active goals, and quick-action shortcuts
- **AI Memory & Chat System** — Floating chat sidebar with persistent conversation history and AI-powered responses
- **Goal Tracker & Coach** — Create, track, and manage goals with AI-generated coaching nudges and progress bars
- **Study & Business Workspace** — Toggle between study mode (flashcards) and business mode (Kanban board)
- **Mock Google Calendar** — Monthly calendar view with event management and upcoming events preview
- **Framer Motion Animations** — Smooth page transitions, micro-interactions, and glassmorphism effects
- **Dark Futuristic Theme** — Deep dark backgrounds, neon accent colors, and premium glassmorphism UI

## Tech Stack

- **Frontend:** React 19, TypeScript, Tailwind CSS 4, Framer Motion, Lucide React
- **Backend:** Express 4, tRPC 11, Drizzle ORM
- **Database:** MySQL/TiDB (via Drizzle)
- **Authentication:** Manus OAuth
- **Styling:** Tailwind CSS with custom glassmorphism and neon utilities
- **UI Components:** shadcn/ui

## Getting Started

### Prerequisites

- Node.js 22+ and pnpm 10+
- MySQL/TiDB database

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd project-titan-ai
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Set up environment variables**
   Create a `.env.local` file in the root directory with the following variables:

   ```env
   # Database
   DATABASE_URL=mysql://user:password@localhost:3306/titan_ai

   # Manus OAuth
   VITE_APP_ID=your_manus_app_id
   OAUTH_SERVER_URL=https://api.manus.im
   VITE_OAUTH_PORTAL_URL=https://oauth.manus.im
   JWT_SECRET=your_jwt_secret_key

   # Owner Info
   OWNER_NAME=Your Name
   OWNER_OPEN_ID=your_open_id

   # Analytics
   VITE_ANALYTICS_ENDPOINT=https://analytics.example.com
   VITE_ANALYTICS_WEBSITE_ID=your_website_id

   # LLM Integration (Optional)
   OPENAI_API_KEY=your_openai_api_key
   ANTHROPIC_API_KEY=your_anthropic_api_key

   # Manus Built-in APIs
   BUILT_IN_FORGE_API_URL=https://api.manus.im/forge
   BUILT_IN_FORGE_API_KEY=your_forge_api_key
   VITE_FRONTEND_FORGE_API_URL=https://api.manus.im/forge
   VITE_FRONTEND_FORGE_API_KEY=your_frontend_forge_api_key
   ```

4. **Initialize the database**
   ```bash
   pnpm drizzle-kit generate
   pnpm drizzle-kit migrate
   ```

5. **Start the development server**
   ```bash
   pnpm dev
   ```

   The app will be available at `http://localhost:3000`

## Project Structure

```
project-titan-ai/
├── client/                    # React frontend
│   ├── src/
│   │   ├── pages/            # Page components (Home, Goals, Calendar, etc.)
│   │   ├── components/       # Reusable UI components
│   │   ├── contexts/         # React contexts (Theme, Auth)
│   │   ├── hooks/            # Custom hooks
│   │   ├── lib/              # Utilities and tRPC client
│   │   ├── App.tsx           # Main app component with routing
│   │   ├── main.tsx          # React entry point
│   │   └── index.css         # Global styles with theme variables
│   ├── index.html            # HTML template
│   └── public/               # Static assets
├── server/                    # Express backend
│   ├── routers.ts            # tRPC procedure definitions
│   ├── db.ts                 # Database query helpers
│   ├── storage.ts            # S3 storage helpers
│   └── _core/                # Core server utilities
├── drizzle/                   # Database schema and migrations
│   ├── schema.ts             # Table definitions
│   └── migrations/           # Generated SQL migrations
├── shared/                    # Shared types and constants
├── package.json              # Dependencies and scripts
├── tsconfig.json             # TypeScript configuration
├── tailwind.config.ts        # Tailwind CSS configuration
└── vite.config.ts            # Vite configuration
```

## Available Scripts

- `pnpm dev` — Start development server with hot reload
- `pnpm build` — Build for production
- `pnpm start` — Run production build
- `pnpm check` — Type-check with TypeScript
- `pnpm test` — Run tests with Vitest
- `pnpm format` — Format code with Prettier
- `pnpm drizzle-kit generate` — Generate database migrations

## Database Schema

### Tables

- **users** — User accounts with OAuth integration
- **goals** — User goals with progress tracking and categories
- **chatMessages** — Chat conversation history
- **calendarEvents** — Calendar events and meetings
- **notes** — Study and business notes
- **flashcards** — Study flashcards for active recall
- **kanbanBoards** — Kanban board projects
- **kanbanCards** — Tasks within Kanban boards

## API Routes (tRPC)

### Authentication
- `auth.me` — Get current user
- `auth.logout` — Logout user

### Goals
- `goals.list` — Get all user goals
- `goals.create` — Create new goal
- `goals.update` — Update goal
- `goals.delete` — Delete goal

### Chat
- `chat.history` — Get chat message history
- `chat.send` — Send chat message

### Calendar
- `calendar.list` — Get all events
- `calendar.create` — Create event
- `calendar.update` — Update event
- `calendar.delete` — Delete event

### Notes
- `notes.list` — Get all notes
- `notes.create` — Create note
- `notes.update` — Update note
- `notes.delete` — Delete note

### Flashcards
- `flashcards.list` — Get all flashcards
- `flashcards.create` — Create flashcard
- `flashcards.update` — Update flashcard
- `flashcards.delete` — Delete flashcard

### Kanban
- `kanban.boards` — Get all boards
- `kanban.createBoard` — Create board
- `kanban.cards` — Get board cards
- `kanban.createCard` — Create card
- `kanban.updateCard` — Update card
- `kanban.deleteCard` — Delete card

## Deployment

### Vercel

1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Vercel**
   - Go to [vercel.com](https://vercel.com)
   - Import your GitHub repository
   - Add environment variables in Vercel settings
   - Deploy

3. **Database Setup**
   - Use a managed MySQL service (PlanetScale, AWS RDS, etc.)
   - Update `DATABASE_URL` in Vercel environment variables

### Environment Variables for Production

Ensure all variables from `.env.local` are added to your Vercel project settings.

## Customization

### Theme Colors

Edit `client/src/index.css` to customize the dark theme:

```css
.dark {
  --primary: oklch(0.65 0.32 262);
  --accent: oklch(0.7 0.32 262);
  --background: oklch(0.08 0.01 262);
  /* ... other variables */
}
```

### Glassmorphism Effects

Modify `.glassmorphism-dark` class in `index.css` to adjust transparency and blur:

```css
.glassmorphism-dark {
  @apply bg-black/30 backdrop-blur-xl border border-white/10 rounded-lg;
}
```

### Framer Motion Animations

Adjust animation timing in component files (e.g., `client/src/components/Navbar.tsx`):

```tsx
transition={{ duration: 0.4 }} // Increase for slower animations
```

## LLM Integration

To enable AI-powered responses:

1. Set up OpenAI or Anthropic API keys in environment variables
2. Modify `server/routers.ts` `chat.send` procedure to call LLM:

```ts
const response = await invokeLLM({
  messages: [
    { role: "system", content: "You are a helpful productivity assistant." },
    { role: "user", content: input.content },
  ],
});
```

3. Store and return the LLM response

## Contributing

1. Create a feature branch: `git checkout -b feature/your-feature`
2. Commit changes: `git commit -m "Add your feature"`
3. Push to branch: `git push origin feature/your-feature`
4. Open a pull request

## License

MIT

## Support

For issues and questions, please open an issue on GitHub or contact the development team.

---

**Built with ❤️ using Manus**
